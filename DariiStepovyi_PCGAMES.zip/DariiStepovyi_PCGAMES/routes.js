import express from 'express';
import { requireAuth } from './utils/auth.js';

import { accounts } from './controllers/accounts.js';
import { dashboard } from './controllers/dashboard.js';
import { collection } from './controllers/collection.js';
import { welcome } from './controllers/welcome.js';
import { about } from './controllers/about.js';

var router = express.Router();

router.get('/', welcome.index);
router.get('/login', accounts.loginView);
router.post('/login', accounts.login);
router.get('/signup', accounts.signupView);
router.post('/signup', accounts.signup);
router.get('/logout', accounts.logout);

router.get('/dashboard', requireAuth, dashboard.index);
router.post('/categories/add', requireAuth, dashboard.addCategory);
router.post('/categories/:id/delete', requireAuth, dashboard.deleteCategory);

router.get('/collection/:id', requireAuth, collection.show);
router.post('/collection/:id/items/add', requireAuth, collection.addItem);
router.get('/collection/:categoryId/items/:itemId/edit', requireAuth, collection.editItemView);
router.post('/collection/:categoryId/items/:itemId/edit', requireAuth, collection.updateItem);
router.post('/collection/:categoryId/items/:itemId/delete', requireAuth, collection.deleteItem);

router.get('/about', about.index);

export default router;
