import express from 'express';
import session from 'express-session';
import fileUpload from 'express-fileupload';
import logger from "./utils/logger.js";
import routes from './routes.js';
import { create } from 'express-handlebars';

var app = express();
var port = 3000;

app.use(express.static("public"));

app.use(express.urlencoded({ extended: false }));

app.use(fileUpload({
  useTempFiles: true,
  tempFileDir: './temp/',
  limits: { fileSize: 5000000 },
  abortOnLimit: true
}));

app.use(session({
  secret: 'my-secret-key-123',
  name: 'session-cookie',
  resave: false,
  saveUninitialized: false,
  rolling: false,
  cookie: {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,
    maxAge: 28800000
  }
}));

app.use(function(req, res, next) {
  if (req.session && req.session.user) {
    res.locals.currentUser = req.session.user;
  } else {
    res.locals.currentUser = null;
  }
  res.locals.currentPath = req.path;
  next();
});

var hbs = create({
  extname: '.hbs',
  layoutsDir: 'views/layouts',
  partialsDir: 'views/partials',
  defaultLayout: 'main',
  helpers: {
    eq: function(a, b) {
      return a === b;
    }
  }
});
app.engine(".hbs", hbs.engine);
app.set("view engine", ".hbs");

app.use("/", routes);

app.listen(port, function() {
  console.log("Server running on port " + port);
});
