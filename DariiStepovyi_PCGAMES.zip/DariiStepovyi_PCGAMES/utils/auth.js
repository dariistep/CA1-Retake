export function requireAuth(req, res, next) {
  var loggedIn = false;
  if (req.session) {
    if (req.session.user) {
      if (req.session.user.id) {
        loggedIn = true;
      }
    }
  }

  if (loggedIn == false) {
    res.redirect('/login');
    return;
  }

  next();
}

