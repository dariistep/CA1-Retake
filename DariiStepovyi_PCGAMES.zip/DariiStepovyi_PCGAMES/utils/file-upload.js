import path from 'path';
import fs from 'fs/promises';
import { v4 as uuidv4 } from 'uuid';

async function checkFolder(folder) {
  try {
    await fs.access(folder);
  } catch {
    await fs.mkdir(folder, { recursive: true });
  }
}

export var fileUploadUtil = {
  async handleImageUpload(file, type) {
    if (!file) {
      return null;
    }

    var allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    var isValid = false;
    for (var i = 0; i < allowedTypes.length; i++) {
      if (file.mimetype === allowedTypes[i]) {
        isValid = true;
        break;
      }
    }

    if (!isValid) {
      throw new Error('Invalid file type. Only JPEG, PNG, GIF, and WebP images allowed.');
    }

    var ext = path.extname(file.name);
    var filename = uuidv4() + ext;

    var folder;
    if (type === 'category') {
      folder = 'public/images/uploads/categories/';
    } else if (type === 'game') {
      folder = 'public/images/uploads/games/';
    } else if (type === 'profile') {
      folder = 'public/images/uploads/profiles/';
    } else {
      folder = 'public/images/uploads/';
    }

    var fullPath = folder + filename;

    await checkFolder(folder);

    await file.mv(fullPath);

    var webPath = '/images/uploads/';
    if (type === 'category') {
      webPath = webPath + 'categories/';
    } else if (type === 'game') {
      webPath = webPath + 'games/';
    } else if (type === 'profile') {
      webPath = webPath + 'profiles/';
    }
    webPath = webPath + filename;

    return webPath;
  },

  validateImageFile: function(file) {
    if (!file) {
      return { valid: false, error: 'No file' };
    }

    var allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    var typeOk = false;
    for (var i = 0; i < allowedTypes.length; i++) {
      if (file.mimetype === allowedTypes[i]) {
        typeOk = true;
        break;
      }
    }

    if (!typeOk) {
      return { valid: false, error: 'Invalid file type. Only JPEG, PNG, GIF, and WebP allowed.' };
    }

    var maxSize = 5000000;
    if (file.size > maxSize) {
      return { valid: false, error: 'File too big. Max 5MB.' };
    }

    return { valid: true };
  }
};
