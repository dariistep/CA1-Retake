import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';
import { v4 as uuidv4 } from 'uuid';

var adapter = new JSONFile('data/db.json');
var db = new Low(adapter, { users: [] });

async function readDb() {
  await db.read();
  if (!db.data) {
    db.data = { users: [] };
  }
}

export var userStore = {
  async getUserByEmail(email) {
    await readDb();
    var users = db.data.users;
    var user = null;
    for (var i = 0; i < users.length; i++) {
      if (users[i].email === email) {
        user = users[i];
        break;
      }
    }
    return user;
  },

  async getUserById(id) {
    await readDb();
    var users = db.data.users;
    var user = null;
    for (var i = 0; i < users.length; i++) {
      if (users[i].id === id) {
        user = users[i];
        break;
      }
    }
    return user;
  },

  async addUser(data) {
    await readDb();
    var email = data.email;
    var password = data.password;
    var name = data.name;
    var profileImage = data.profileImage || '';

    var users = db.data.users;
    for (var i = 0; i < users.length; i++) {
      if (users[i].email === email) {
        throw new Error('Email already in use');
      }
    }

    var newUser = {
      id: uuidv4(),
      email: email,
      password: password,
      name: name,
      profileImage: profileImage,
      categories: []
    };
    db.data.users.push(newUser);
    await db.write();
    return newUser;
  },

  async getUserCategories(userId) {
    await readDb();
    var user = await this.getUserById(userId);
    if (user) {
      return user.categories;
    } else {
      return [];
    }
  },

  async addCategoryToUser(userId, data) {
    await readDb();
    var user = await this.getUserById(userId);
    if (!user) {
      throw new Error('User not found');
    }

    var title = data.title;
    var imagePath = data.imagePath || '';

    var newCategory = {
      id: uuidv4(),
      title: title,
      imagePath: imagePath,
      items: []
    };

    user.categories.push(newCategory);
    await db.write();
    return newCategory;
  },

  async deleteCategoryFromUser(userId, categoryId) {
    await readDb();
    var user = null;
    for (var i = 0; i < db.data.users.length; i++) {
      if (db.data.users[i].id === userId) {
        user = db.data.users[i];
        break;
      }
    }
    if (!user) throw new Error('User not found');

    var idx = -1;
    for (var j = 0; j < user.categories.length; j++) {
      if (user.categories[j].id === categoryId) {
        idx = j;
        break;
      }
    }
    if (idx >= 0) {
      user.categories.splice(idx, 1);
      await db.write();
    }
  },

  async addItemToCategory(userId, categoryId, data) {
    await readDb();
    var user = null;
    for (var i = 0; i < db.data.users.length; i++) {
      if (db.data.users[i].id === userId) {
        user = db.data.users[i];
        break;
      }
    }
    if (!user) throw new Error('User not found');

    var cat = null;
    for (var j = 0; j < user.categories.length; j++) {
      if (user.categories[j].id === categoryId) {
        cat = user.categories[j];
        break;
      }
    }
    if (!cat) throw new Error('Category not found');

    var item = {
      id: uuidv4(),
      title: data.title,
      platform: data.platform || '',
      genre: data.genre || '',
      year: data.year || null,
      rating: data.rating || null,
      imagePath: data.imagePath || ''
    };
    cat.items.push(item);
    await db.write();
    return item;
  },

  async updateItemInCategory(userId, categoryId, itemId, data) {
    await readDb();
    var user = null;
    for (var i = 0; i < db.data.users.length; i++) {
      if (db.data.users[i].id === userId) {
        user = db.data.users[i];
        break;
      }
    }
    if (!user) throw new Error('User not found');

    var cat = null;
    for (var j = 0; j < user.categories.length; j++) {
      if (user.categories[j].id === categoryId) {
        cat = user.categories[j];
        break;
      }
    }
    if (!cat) throw new Error('Category not found');

    var item = null;
    for (var k = 0; k < cat.items.length; k++) {
      if (cat.items[k].id === itemId) {
        item = cat.items[k];
        break;
      }
    }
    if (!item) throw new Error('Item not found');

    item.title = data.title;
    item.platform = data.platform || '';
    item.genre = data.genre || '';
    item.year = data.year || null;
    item.rating = data.rating || null;
    item.imagePath = data.imagePath || '';
    await db.write();
    return item;
  },

  async deleteItemFromCategory(userId, categoryId, itemId) {
    await readDb();
    var user = null;
    for (var i = 0; i < db.data.users.length; i++) {
      if (db.data.users[i].id === userId) {
        user = db.data.users[i];
        break;
      }
    }
    if (!user) throw new Error('User not found');

    var cat = null;
    for (var j = 0; j < user.categories.length; j++) {
      if (user.categories[j].id === categoryId) {
        cat = user.categories[j];
        break;
      }
    }
    if (!cat) throw new Error('Category not found');

    var itemIndex = -1;
    for (var k = 0; k < cat.items.length; k++) {
      if (cat.items[k].id === itemId) {
        itemIndex = k;
        break;
      }
    }
    if (itemIndex >= 0) {
      cat.items.splice(itemIndex, 1);
      await db.write();
    }
  },
};

