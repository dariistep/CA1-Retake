import { userStore } from '../models/user-store.js';

export var about = {
  index: async function(req, res) {
    var userId = null;
    if (req.session && req.session.user && req.session.user.id) {
      userId = req.session.user.id;
    }

    var stats = null;
    if (userId) {
      var user = await userStore.getUserById(userId);
      var categories = [];
      if (user && user.categories) {
        categories = user.categories;
      }

      var totalCategories = categories.length;

      // Calculate total items
      var totalItems = 0;
      for (var i = 0; i < categories.length; i++) {
        if (categories[i].items) {
          totalItems += categories[i].items.length;
        }
      }

      var avg = totalCategories ? (totalItems / totalCategories) : 0;

      // Find collection with most items
      var most = null;
      for (var i = 0; i < categories.length; i++) {
        var itemCount = categories[i].items ? categories[i].items.length : 0;
        if (!most || itemCount > (most.items ? most.items.length : 0)) {
          most = categories[i];
        }
      }

      // Find collection with least items
      var least = null;
      for (var i = 0; i < categories.length; i++) {
        var itemCount = categories[i].items ? categories[i].items.length : 0;
        if (!least || itemCount < (least.items ? least.items.length : 0)) {
          least = categories[i];
        }
      }

      stats = {
        totalCategories: totalCategories,
        totalItems: totalItems,
        averageItemsPerCategory: avg,
        mostCollection: most ? most.title + ' (' + (most.items ? most.items.length : 0) + ')' : '—',
        leastCollection: least ? least.title + ' (' + (least.items ? least.items.length : 0) + ')' : '—'
      };
    }
    res.render('about', { title: 'About', stats: stats });
  }
};

