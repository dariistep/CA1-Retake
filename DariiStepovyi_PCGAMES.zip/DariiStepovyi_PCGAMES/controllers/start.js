'use strict';

import logger from "../utils/logger.js";
import appStore from "../models/app-store.js";

var start = {
  createView: function(request, response) {
    logger.info("Start page loading!");

    var viewData = {
      title: "CA1 Starter App",
      info: appStore.getAppInfo()
    };

    response.render('start', viewData);
  }
};

export default start;
