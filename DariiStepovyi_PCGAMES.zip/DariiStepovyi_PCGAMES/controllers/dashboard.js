import { userStore } from '../models/user-store.js';
import { fileUploadUtil } from '../utils/file-upload.js';

export var dashboard = {
  index: async function(req, res) {
    var userId = req.session.user.id;
    var categories = await userStore.getUserCategories(userId);

    var totalGames = 0;
    for (var i = 0; i < categories.length; i++) {
      totalGames += categories[i].items.length;
    }

    res.render('dashboard', {
      title: 'Your Categories',
      categories: categories,
      totalCategories: categories.length,
      totalGames: totalGames
    });
  },

  addCategory: async function(req, res) {
    var userId = req.session.user.id;
    var title = req.body.title;
    var imagePath = req.body.imagePath;

    if (!title || title.trim() === '') {
      var categories = await userStore.getUserCategories(userId);
      return res.status(400).render('dashboard', {
        title: 'Your Categories',
        error: 'Title is required',
        categories: categories
      });
    }

    var finalImagePath = '';
    if (imagePath) {
      finalImagePath = imagePath.trim();
    }

    if (req.files && req.files.categoryImage) {
      var validation = fileUploadUtil.validateImageFile(req.files.categoryImage);
      if (!validation.valid) {
        var categories = await userStore.getUserCategories(userId);
        return res.status(400).render('dashboard', {
          title: 'Your Categories',
          error: validation.error,
          categories: categories
        });
      }

      try {
        var uploadedPath = await fileUploadUtil.handleImageUpload(req.files.categoryImage, 'category');
        finalImagePath = uploadedPath;
      } catch (error) {
        var categories = await userStore.getUserCategories(userId);
        return res.status(400).render('dashboard', {
          title: 'Your Categories',
          error: 'Image upload failed: ' + error.message,
          categories: categories
        });
      }
    }

    var categoryData = { title: title.trim(), imagePath: finalImagePath };
    await userStore.addCategoryToUser(userId, categoryData);
    res.redirect('/dashboard');
  },

  deleteCategory: async function(req, res) {
    var userId = req.session.user.id;
    var categoryId = req.params.id;
    await userStore.deleteCategoryFromUser(userId, categoryId);
    res.redirect('/dashboard');
  }
};

