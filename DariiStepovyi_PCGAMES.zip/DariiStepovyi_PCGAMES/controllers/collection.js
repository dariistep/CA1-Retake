import { userStore } from '../models/user-store.js';
import { fileUploadUtil } from '../utils/file-upload.js';

export var collection = {
  show: async function(req, res) {
    var user = await userStore.getUserById(req.session.user.id);
    var category = null;

    if (user && user.categories) {
      for (var i = 0; i < user.categories.length; i++) {
        if (user.categories[i].id === req.params.id) {
          category = user.categories[i];
          break;
        }
      }
    }

    if (!category) {
      var userCategories = user && user.categories ? user.categories : [];
      return res.status(404).render('dashboard', {
        title: 'Your Categories',
        error: 'Category not found',
        categories: userCategories
      });
    }

    res.render('collection', { title: category.title, category: category });
  },

  addItem: async function(req, res) {
    var userId = req.session.user.id;
    var categoryId = req.params.id;
    var title = req.body.title;
    var platform = req.body.platform;
    var genre = req.body.genre;
    var year = req.body.year;
    var rating = req.body.rating;
    var imagePath = req.body.imagePath;

    if (!title || !title.trim()) {
      return res.redirect('/collection/' + categoryId);
    }

    year = year ? parseInt(year, 10) : null;
    rating = rating ? parseFloat(rating) : null;
    var finalImagePath = '';
    if (imagePath && imagePath.trim) {
      finalImagePath = imagePath.trim();
    }

    // Handle file upload if present
    if (req.files && req.files.gameImage) {
      try {
        var uploadedPath = await fileUploadUtil.handleImageUpload(req.files.gameImage, 'game');
        finalImagePath = uploadedPath;
      } catch (error) {
        // For now, just continue without the image if upload fails
        console.error('Image upload failed:', error.message);
      }
    }

    await userStore.addItemToCategory(userId, categoryId, {
      title: title.trim(),
      platform: platform,
      genre: genre,
      year: year,
      rating: rating,
      imagePath: finalImagePath
    });
    res.redirect('/collection/' + categoryId);
  },

  editItemView: async function(req, res) {
    var user = await userStore.getUserById(req.session.user.id);
    var category = null;
    var item = null;

    if (user && user.categories) {
      for (var i = 0; i < user.categories.length; i++) {
        if (user.categories[i].id === req.params.categoryId) {
          category = user.categories[i];
          break;
        }
      }
    }

    if (category && category.items) {
      for (var j = 0; j < category.items.length; j++) {
        if (category.items[j].id === req.params.itemId) {
          item = category.items[j];
          break;
        }
      }
    }

    if (!category || !item) {
      return res.redirect('/collection/' + req.params.categoryId);
    }

    res.render('edit-item', {
      title: 'Edit ' + item.title,
      categoryId: category.id,
      item: item
    });
  },

  updateItem: async function(req, res) {
    var userId = req.session.user.id;
    var categoryId = req.params.categoryId;
    var itemId = req.params.itemId;
    var title = req.body.title;
    var platform = req.body.platform;
    var genre = req.body.genre;
    var year = req.body.year;
    var rating = req.body.rating;
    var imagePath = req.body.imagePath;

    year = year ? parseInt(year, 10) : null;
    rating = rating ? parseFloat(rating) : null;
    var finalImagePath = '';
    if (imagePath && imagePath.trim) {
      finalImagePath = imagePath.trim();
    }

    // Handle file upload if present
    if (req.files && req.files.gameImage) {
      try {
        var uploadedPath = await fileUploadUtil.handleImageUpload(req.files.gameImage, 'game');
        finalImagePath = uploadedPath;
      } catch (error) {
        console.error('Image upload failed:', error.message);
      }
    }

    var titleToSave = '';
    if (title && title.trim) {
      titleToSave = title.trim();
    }

    await userStore.updateItemInCategory(userId, categoryId, itemId, {
      title: titleToSave,
      platform: platform,
      genre: genre,
      year: year,
      rating: rating,
      imagePath: finalImagePath
    });
    res.redirect('/collection/' + categoryId);
  },

  deleteItem: async function(req, res) {
    var userId = req.session.user.id;
    var categoryId = req.params.categoryId;
    var itemId = req.params.itemId;
    await userStore.deleteItemFromCategory(userId, categoryId, itemId);
    res.redirect('/collection/' + categoryId);
  }
};

