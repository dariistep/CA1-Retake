import { userStore } from '../models/user-store.js';
import { fileUploadUtil } from '../utils/file-upload.js';

export var accounts = {
  loginView: function(req, res) {
    res.render('login', { title: 'Login' });
  },

  signupView: function(req, res) {
    res.render('signup', { title: 'Signup' });
  },

  login: async function(req, res) {
    var email = req.body.email;
    var password = req.body.password;

    var user = await userStore.getUserByEmail(email);

    if (!user) {
      return res.status(401).render('login', {
        title: 'Login',
        error: 'Invalid email or password'
      });
    }

    if (user.password !== password) {
      return res.status(401).render('login', {
        title: 'Login',
        error: 'Invalid email or password'
      });
    }

    req.session.user = {
      id: user.id,
      email: user.email,
      name: user.name,
      profileImage: user.profileImage
    };

    res.redirect('/dashboard');
  },

  signup: async function(req, res) {
    var email = req.body.email;
    var password = req.body.password;
    var displayName = req.body.displayName;

    if (!email || !password || !displayName) {
      return res.status(400).render('signup', {
        title: 'Signup',
        error: 'All fields are required'
      });
    }

    // Basic password validation
    if (password.length < 6) {
      return res.status(400).render('signup', {
        title: 'Signup',
        error: 'Password must be at least 6 characters long'
      });
    }

    // Check if password has at least one letter and one number
    var hasLetter = false;
    var hasNumber = false;
    for (var i = 0; i < password.length; i++) {
      var char = password[i];
      if (char >= 'a' && char <= 'z' || char >= 'A' && char <= 'Z') {
        hasLetter = true;
      }
      if (char >= '0' && char <= '9') {
        hasNumber = true;
      }
    }

    if (!hasLetter || !hasNumber) {
      return res.status(400).render('signup', {
        title: 'Signup',
        error: 'Password must contain at least one letter and one number'
      });
    }

    var profileImagePath = '';

    if (req.files && req.files.profileImage) {
      try {
        profileImagePath = await fileUploadUtil.handleImageUpload(req.files.profileImage, 'profile');
      } catch (error) {
        return res.status(400).render('signup', {
          title: 'Signup',
          error: 'Profile image upload failed: ' + error.message
        });
      }
    }

    try {
      var userData = {
        email: email,
        password: password,
        name: displayName,
        profileImage: profileImagePath
      };
      var user = await userStore.addUser(userData);

      req.session.user = {
        id: user.id,
        email: user.email,
        name: user.name,
        profileImage: user.profileImage
      };

      res.redirect('/dashboard');
    } catch (err) {
      res.status(400).render('signup', { title: 'Signup', error: err.message });
    }
  },

  logout: function(req, res) {
    req.session.destroy(function() {
      res.redirect('/');
    });
  }
};

