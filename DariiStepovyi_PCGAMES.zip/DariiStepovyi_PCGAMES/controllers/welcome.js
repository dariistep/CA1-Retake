import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';
import fs from 'fs/promises';

var adapter = new JSONFile('data/db.json');
var db = new Low(adapter, { users: [] });

async function readDb() {
  await db.read();
  if (!db.data) {
    db.data = { users: [] };
  }
}

async function getAppInfo() {
  try {
    var data = await fs.readFile('data/app-info.json', 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return {
      appName: 'PC Games Collection',
      description: 'Organize and manage your PC game library',
      version: '1.0.0'
    };
  }
}

export var welcome = {
  index: async function(req, res) {
    await readDb();
    var users = db.data.users;
    var totalUsers = users.length;

    // Calculate total categories
    var totalCategories = 0;
    for (var i = 0; i < users.length; i++) {
      if (users[i].categories) {
        totalCategories += users[i].categories.length;
      }
    }

    // Calculate total items
    var totalItems = 0;
    for (var i = 0; i < users.length; i++) {
      if (users[i].categories) {
        for (var j = 0; j < users[i].categories.length; j++) {
          if (users[i].categories[j].items) {
            totalItems += users[i].categories[j].items.length;
          }
        }
      }
    }

    // Find user with most and least items
    var userItemCounts = [];
    for (var i = 0; i < users.length; i++) {
      var userItemCount = 0;
      if (users[i].categories) {
        for (var j = 0; j < users[i].categories.length; j++) {
          if (users[i].categories[j].items) {
            userItemCount += users[i].categories[j].items.length;
          }
        }
      }
      userItemCounts.push({ user: users[i], count: userItemCount });
    }

    var most = null;
    var least = null;
    if (userItemCounts.length > 0) {
      most = userItemCounts[0];
      least = userItemCounts[0];
      for (var i = 1; i < userItemCounts.length; i++) {
        if (userItemCounts[i].count > most.count) {
          most = userItemCounts[i];
        }
        if (userItemCounts[i].count < least.count) {
          least = userItemCounts[i];
        }
      }
    }

    var appInfo = await getAppInfo();

    res.render('welcome', {
      title: 'Welcome',
      appInfo: appInfo,
      stats: {
        totalUsers: totalUsers,
        totalCategories: totalCategories,
        totalItems: totalItems,
        mostUser: most ? most.user.email : '—',
        leastUser: least ? least.user.email : '—'
      }
    });
  }
};

