PC Games Collection - Extra Features

This document lists all the extra features I implemented beyond the basic assignment requirements.

Basic Requirements

The assignment asked for:
Simple user signup and login
Basic categories and items (games)
Simple statistics on welcome/about pages
Basic image handling with hardcoded paths
One simple extra feature

Extra Features I Added

1. Delete Functionality
Where to find it:
Dashboard page: Red "Delete" button next to each category
Collection page: Red "Delete" button next to each game
Both have confirmation dialogs to prevent accidents

2. Image Upload System
Where to find it:
Signup page: Upload a profile picture
Dashboard: Upload category cover images
Collection page: Upload game cover images when adding/editing games

Technical details:
Supports JPEG, PNG, GIF, WebP formats
5MB file size limit
Files are organized in separate folders (profiles, categories, games)
Has proper error handling if upload fails

3. Advanced Statistics
Where to find it:
Welcome page: Global stats across all users
About page: Personal stats for logged-in users

Personal Stats (About page):
Total categories and games
Average games per category
Which collection has the most games
Which collection has the least games

Global Stats (Welcome page):
Total users on the platform
Total categories across all users
Total games across all users
User with most games
User with least games

4. Search Functionality
Where to find it: Collection detail pages (when viewing games in a category)

How it works:
Type in the search box to filter games instantly
Searches both game titles and details (platform, genre, etc.)
Clear button to reset the search
Works as you type (no need to press enter)

5. Sorting Features
Where to find it: Dashboard page (dropdown menu above categories)

Sort options:
Name (A-Z)
Name (Z-A)
Most games first
Least games first

6. Complete Game Management
Where to find it: Collection pages

Features:
Add games with detailed information (title, platform, genre, year, rating)
Edit existing games on a dedicated edit page
Upload/change game cover images
All form fields are properly validated

7. Enhanced User Experience

Features:
Profile images show in the navigation bar
Image fallbacks when pictures don't load
Confirmation dialogs for delete actions
Error messages that actually help
Loading states and user feedback
Responsive design that works on different screen sizes

8. Professional File Handling


Technical features:
File type validation
File size limits
Organized storage directories
Error handling for failed uploads
Automatic file naming to prevent conflicts

9. Password Validation Rules
Where to find it: Signup page

Features:
Minimum 6 characters required
Must contain at least one letter and one number
Client-side validation with helpful error messages
Server-side validation for security
Clear password requirements shown to users

10. Profile Picture Preview
Where to find it: Signup page

Features:
Live preview of selected profile image
Shows how the image will appear in navigation
Works with existing file upload system
Simple and user-friendly interface



Technical Implementation

All features use:
Basic JavaScript
Express.js for server functionality
LowDB for simple database operations
Express-fileupload for image handling
Handlebars for page templates
Standard HTML forms and basic CSS

